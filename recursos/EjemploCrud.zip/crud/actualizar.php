<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Editar datos</title>
</head>
<body>
	<?php
		if(isset($_GET['id'])){
			require_once "php/connect.php";
			$id=$_GET['id'];
			$query="SELECT * FROM usuarios WHERE id='$id'";
			$consulta1=$mysqli->query($query);
			$fila=$consulta1->fetch_array(MYSQLI_ASSOC);
			echo '<form action="./procesos/editarDatos.php" method="POST">
				<input type="hidden" name="id" value="'.$fila['id'].'">
				<label>Nombre</label><input required="required" type="text" name="nombre" value="'.$fila['nombre'].'"><br><br>
				<label>Apellido</label><input required="required" type="text" name="apellido" value="'.$fila['apellido'].'"><br><br>
				<label>Email</label><input required="required" type="email" name="email" value="'.$fila['email'].'"><br><br>		
				<input type="submit" value="Actualizar">
			</form>';
		}else{
			echo "Ocurrio un error inesperado";
			echo "	<br><a href='index.php'>Volver<a>";
		}
	?>
</body>
</html>