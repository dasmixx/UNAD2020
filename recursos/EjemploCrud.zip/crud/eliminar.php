<?php
	require_once "php/connect.php";
	if(isset($_GET['id'])){
		$id=$_GET['id'];
		$query="DELETE FROM usuarios WHERE id='$id'";		
		if($mysqli->query($query)){
			echo "Registro eliminado";
			echo "	<br><a href='index.php'>Volver<a>";
		}else{
			echo "Error no se pudo eliminar el registro";
			echo "	<br><a href='index.php'>Volver<a>";
			
		}
	}else{
		echo "Error no se pudo procesar la peticion";
		echo "	<br><a href='index.php'>Volver<a>";
	}