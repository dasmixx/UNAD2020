<?php
	$palabra=$_POST['palabra'];
	$query="SELECT * FROM usuarios WHERE Nombre LIKE '%$palabra%'";
	$consulta3=$mysqli->query($query);
	if($consulta3->num_rows>=1){
		echo "<table>
		<thead>
			<tr>
				<th>id</th>
				<th>Nombre</th>
				<th>Apellido</th>
				<th>Email</th>			
			</tr>
		</thead>
		<tbody>";
		while($fila=$consulta3->fetch_array(MYSQLI_ASSOC)){
			echo "<tr>
				<td>".$fila['id']."</td>
				<td>".$fila['nombre']."</td>
				<td>".$fila['apellido']."</td>
				<td>".$fila['email']."</td>			
			</tr>";
		}
		echo "</tbody>
	</table>";
		echo "<br><a href='index.php'>volver<a>";
	}else{
		echo "No hemos encotrado ningun registro con la palabra ".$palabra;
		echo "<br><a href='index.php'>volver<a>";
	}